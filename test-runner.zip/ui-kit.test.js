﻿
import { TestRunner } from "../test-runner.js";
import {
    KitComponent,
    KitComponentOptions,
    KitComponentType,
    KitDependencyManager,
    KitMessenger,
    KitNavigator,
    KitRenderer,
    KitResourceManager,
    KitStartup
} from "./ui-kit.js";

// KitDependencyManager tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitDependencyManager - getWindow()", async t => {

    // arrange
    const expected = "testing";
    const testWindow = {
        prop1: expected
    };
    KitDependencyManager.setWindow(testWindow);

    // act
    const actual = KitDependencyManager.getWindow();

    // assert
    t.is(actual.prop1).equalTo(expected);
   
});

await TestRunner.test("KitDependencyManager - setWindow()", async t => {

    // arrange
    const expected = "testing";
    const testWindow = {
        prop1: expected
    };

    // act
    KitDependencyManager.setWindow(testWindow);

    // assert
    const actual = KitDependencyManager.getWindow();
    t.is(actual.prop1).equalTo(expected);

});

await TestRunner.test("KitDependencyManager - getDocument()", async t => {

    // arrange
    const expected = "testing";
    const testDocument = {
        prop1: expected
    };
    KitDependencyManager.setDocument(testDocument);

    // act
    const actual = KitDependencyManager.getDocument();

    // assert
    t.is(actual.prop1).equalTo(expected);

});

await TestRunner.test("KitDependencyManager - setDocument()", async t => {

    // arrange
    const expected = "testing";
    const testDocument = {
        prop1: expected
    };

    // act
    KitDependencyManager.setDocument(testDocument);

    // assert
    const actual = KitDependencyManager.getDocument();
    t.is(actual.prop1).equalTo(expected);

});

await TestRunner.test("KitDependencyManager - getConsole()", async t => {

    // arrange
    const expected = "testing";
    const testConsole = {
        prop1: expected
    };
    KitDependencyManager.setConsole(testConsole);

    // act
    const actual = KitDependencyManager.getConsole();

    // assert
    t.is(actual.prop1).equalTo(expected);

});

await TestRunner.test("KitDependencyManager - setConsole()", async t => {

    // arrange
    const expected = "testing";
    const testConsole = {
        prop1: expected
    };

    // act
    KitDependencyManager.setConsole(testConsole);

    // assert
    const actual = KitDependencyManager.getConsole();
    t.is(actual.prop1).equalTo(expected);

});

await TestRunner.test("KitDependencyManager - getResourceManager()", async t => {

    // arrange
    const expected = "testing";
    const testResourceManager = {
        prop1: expected
    };
    KitDependencyManager.setResourceManager(testResourceManager);

    // act
    const actual = KitDependencyManager.getResourceManager();

    // assert
    t.is(actual.prop1).equalTo(expected);

});

await TestRunner.test("KitDependencyManager - setResourceManager()", async t => {

    // arrange
    const expected = "testing";
    const testResourceManager = {
        prop1: expected
    };

    // act
    KitDependencyManager.setResourceManager(testResourceManager);

    // assert
    const actual = KitDependencyManager.getResourceManager();
    t.is(actual.prop1).equalTo(expected);

});

await TestRunner.test("KitDependencyManager - get() - key not found returns null", async t => {

    // act
    const actual = KitDependencyManager.get("unit-test");

    // assert
    t.is(actual).falsy();

});

await TestRunner.test("KitDependencyManager - clear()", async t => {

    // arrange
    const key = "unit-test-key";
    KitDependencyManager.set(key, "unit-test-value");

    // act
    KitDependencyManager.clear();

    // assert
    const actual = KitDependencyManager.get(key);
    t.is(actual).falsy();

});

// KitResourceManager tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitResourceManager - fetch()", async t => {

    // arrange
    const expected = "getaddrinfo ENOTFOUND unit-test.org";
    let actual = null;

    // act
    const resourceManager = new KitResourceManager();
    try {
        const response = await resourceManager.fetch("http://unit-test.org/test");
    }
    catch (error) {
        actual = error.cause.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitResourceManager - import()", async t => {

    // arrange
    const expected = "ERR_MODULE_NOT_FOUND";
    let actual = null;

    // act
    const resourceManager = new KitResourceManager();
    try {
        const response = await resourceManager.import("unit-test-module");
    }
    catch (error) {
        actual = error.code;
    }

    // assert
    t.is(actual).equalTo(expected);

});

// KitNavigator tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitNavigator - initialize()", async t => {

    // arrange
    let documentAddEventListenerCalled = false;
    let windowAddEventListenerCalled = false;
    const expectedUrl = "http://unit-test.org";
    let actualUrl = null;
    const mockDocument = {
        body: {
            addEventListener() {
                documentAddEventListenerCalled = true;
            }
        },
        location: {
            href: expectedUrl
        }
    };
    KitDependencyManager.setDocument(mockDocument);
    const mockWindow = {
        addEventListener() {
            windowAddEventListenerCalled = true;
        }
    };
    KitDependencyManager.setWindow(mockWindow);
    const model = {
        onNavigation(url) {
            actualUrl = url;
        }
    };
    const component = new KitComponent({ model: model });
    KitComponent.add(component);
    KitMessenger.publish(KitNavigator.navTopicName, null);
    KitMessenger.subscribe(KitNavigator.navTopicName, component.id, "onNavigation");

    // act
    KitNavigator.initialize();

    // assert
    t.is(documentAddEventListenerCalled).true();
    t.is(windowAddEventListenerCalled).true();
    t.is(actualUrl).equalTo(expectedUrl);

});

await TestRunner.test("KitNavigator - navigate()", async t => {

    // arrange
    const startUrl = "http://unit-test.org/start";
    const expectedUrl = "http://unit-test.org/expected";
    let historyUrl = null;
    let subscriberUrl = null;
    const mockDocument = {
        location: {
            href: startUrl
        }
    };
    KitDependencyManager.setDocument(mockDocument);
    const mockWindow = {
        history: {
            pushState(data, unused, url) {
                historyUrl = url;
            }
        }
    };
    KitDependencyManager.setWindow(mockWindow);
    const model = {
        onNavigation(url) {
            subscriberUrl = url;
        }
    };
    const component = new KitComponent({ model: model });
    KitComponent.add(component);
    KitMessenger.publish(KitNavigator.navTopicName, null);
    KitMessenger.subscribe(KitNavigator.navTopicName, component.id, "onNavigation");

    // act
    KitNavigator.navigate(expectedUrl);

    // assert
    t.is(historyUrl).equalTo(expectedUrl);
    t.is(subscriberUrl).equalTo(expectedUrl);

});

await TestRunner.test("KitNavigator - getUrlFragment()", async t => {

    // arrange
    const expectedFragment = "#unit-test";
    const url = `http://unit-test.org/start${expectedFragment}`;
    
    // act
    const actual = KitNavigator.getUrlFragment(url);

    // assert
    t.is(actual).equalTo(expectedFragment);

});

await TestRunner.test("KitNavigator - getUrlFragment() - null url", async t => {

    // act
    const actual = KitNavigator.getUrlFragment(null);

    // assert
    t.is(actual).falsy();

});

await TestRunner.test("KitNavigator - getCurrentUrlFragment()", async t => {

    // arrange
    const expectedFragment = "#unit-test";
    const url = `http://unit-test.org/start${expectedFragment}`;
    const mockDocument = {
        location: {
            href: url
        }
    };
    KitDependencyManager.setDocument(mockDocument);

    // act
    const actual = KitNavigator.getCurrentUrlFragment();

    // assert
    t.is(actual).equalTo(expectedFragment);

});

// KitMessenger tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitMessenger - publish() - no topic name", async t => {

    // arrange
    const expected = "topicName not provided";
    let actual = null;

    // act
    try {
        KitMessenger.publish(null, null);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - publish() - subscriber failed to receive", async t => {

    // arrange
    const expected = "unit-test-error";
    let actual = null;
    const mockConsole = {
        error(error) {
            actual = error.message;
        }
    };
    KitDependencyManager.setConsole(mockConsole);
    const topic = "unit-test-topic";
    const model = {
        onTestPublication(message) {
            throw new Error(expected);
        }
    };
    const component = new KitComponent({ model: model });
    KitComponent.add(component);
    KitMessenger.publish(topic, null);
    KitMessenger.subscribe(topic, component.id, "onTestPublication");

    // act
    KitMessenger.publish(topic, null);

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - publish() - success", async t => {

    // arrange
    const expected = "unit-test-message";
    let actual = null;
    const topic = "unit-test-topic";
    const model = {
        onTestPublication(message) {
            actual = message;
        }
    };
    const component = new KitComponent({ model: model });
    KitComponent.add(component);
    KitMessenger.publish(topic, null);
    KitMessenger.subscribe(topic, component.id, "onTestPublication");

    // act
    KitMessenger.publish(topic, expected);

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - subscribe() - no topic name", async t => {

    // arrange
    const expected = "topicName not provided";
    let actual = null;

    // act
    try {
        KitMessenger.subscribe(null, null, null);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - subscribe() - component id not provided", async t => {

    // arrange
    const topicName = "unit-test-topic";
    const expected = "component id not provided";
    let actual = null;

    // act
    KitMessenger.publish(topicName, null);
    try {
        KitMessenger.subscribe(topicName, null, null);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - subscribe() - component not found", async t => {

    // arrange
    const topicName = "unit-test-topic";
    const componentId = -1;
    const expected = `component not found: ${componentId}`;
    let actual = null;

    // act
    KitMessenger.publish(topicName, null);
    try {
        KitMessenger.subscribe(topicName, componentId, null);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - subscribe() - no model", async t => {

    // arrange
    const topic = "unit-test-topic";
    const model = null;
    const component = new KitComponent({ model: model });
    KitComponent.add(component);
    KitMessenger.publish(topic, null);
    const expected = `model not defined for component.  component id: ${component.id}`;
    let actual = null;

    // act
    try {
        KitMessenger.subscribe(topic, component.id, "onTestPublication");
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - subscribe() - no callback", async t => {

    // arrange
    const topic = "unit-test-topic";
    const model = {
        onTestPublication(message) {
            actual = message;
        }
    };
    const component = new KitComponent({ model: model });
    KitComponent.add(component);
    KitMessenger.publish(topic, null);
    const expected = "callback not provided";
    let actual = null;

    // act
    try {
        KitMessenger.subscribe(topic, component.id, null);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - subscribe() - callback not a function", async t => {

    // arrange
    const topic = "unit-test-topic";
    const model = {};
    const component = new KitComponent({ model: model });
    KitComponent.add(component);
    KitMessenger.publish(topic, null);
    const callback = "onTestPublication";
    const expected = `provided callback is not a function: ${callback}`;
    let actual = null;

    // act
    try {
        KitMessenger.subscribe(topic, component.id, callback);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitMessenger - subscribe() - success", async t => {

    // arrange
    const expected = "unit-test-message";
    let actual = null;
    const topic = "unit-test-topic-2";
    const model = {
        onTestPublication(message) {
            actual = message;
        }
    };
    const component = new KitComponent({ model: model });
    KitComponent.add(component);

    // act
    KitMessenger.subscribe(topic, component.id, "onTestPublication");
    KitMessenger.publish(topic, null);

    // assert
    KitMessenger.publish(topic, expected);
    t.is(actual).equalTo(expected);

});

// KitComponentOptions tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitComponentOptions - constructor()", async t => {

    // act
    const options = new KitComponentOptions();
    options.componentType = KitComponentType.ConditionalComponent;
    options.template = "";
    options.model = null;
    options.modelInput = null;
    options.parent = null;
    options.modelRef = null;
    options.itemRef = null;
    options.itemIndexRef = null;
    options.indexRef = null;
    options.index = null;

    // assert
    t.is(options).truthy();

});

// KitComponent tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitComponent - constructor() - conditional - false", async t => {

    // arrange
    const options = {
        componentType: KitComponentType.ConditionalComponent,
        model: null
    };

    // act
    const component = new KitComponent(options);

    // assert
    t.is(component.model).false();

});

await TestRunner.test("KitComponent - constructor() - conditional - true", async t => {

    // arrange
    const options = {
        componentType: KitComponentType.ConditionalComponent,
        model: "unit-test"
    };

    // act
    const component = new KitComponent(options);

    // assert
    t.is(component.model).true();

});

await TestRunner.test("KitComponent - constructor() - array - empty", async t => {

    // arrange
    const options = {
        componentType: KitComponentType.ArrayComponent,
        model: null
    };

    // act
    const component = new KitComponent(options);

    // assert
    t.is(component.model.length).equalTo(0);

});

await TestRunner.test("KitComponent - constructor() - array - invalid", async t => {

    // arrange
    const options = {
        componentType: KitComponentType.ArrayComponent,
        model: "unit-test"
    };
    const expected = "invalid model. array component model must be an array";
    let actual = null;

    // act
    try {
        const component = new KitComponent(options);
    }
    catch (error) {
        actual = error.message;
    }
    
    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitComponent - constructor() - invalid ref", async t => {

    // arrange
    const ref = "unit-test-ref";
    const options = {
        model: "unit-test",
        modelRef: ref
    };
    const expected = `invalid ref: '${ref}'. may contain only letters, numbers, or underscores.`;
    let actual = null;

    // act
    try {
        const component = new KitComponent(options);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitComponent - constructor() - duplicate ref", async t => {

    // arrange
    const ref = "unit_test_ref";
    let options = {
        model: "unit-test",
        modelRef: ref
    };
    const expected = `duplicate ref: '${ref}'. ref must be unique within the component tree.`;
    let actual = null;
    const parentComponent = new KitComponent(options);
    options = {
        model: "unit-test",
        modelRef: ref,
        parent: parentComponent
    };

    // act
    try {
        const component = new KitComponent(options);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitComponent - onRenderStart()", async t => {

    // arrange
    let id = null;
    let options = {
        model: {
            onRenderStart: async function (componentId) {
                id = componentId;
            }
        }
    };
    const component = new KitComponent(options);

    // act
    component.onRenderStart();

    // assert
    t.is(id).equalTo(component.id);

});

await TestRunner.test("KitComponent - onRenderStart() must be async", async t => {

    // arrange
    let id = null;
    let options = {
        model: {
            onRenderStart: function (componentId) {
                id = componentId;
            }
        }
    };
    const component = new KitComponent(options);
    let actual = null;

    // act
    try {
        component.onRenderStart();
    }
    catch (error) {
        actual = error.message;
    }
    
    // assert
    t.is(actual.startsWith("onRenderStart(componentId, modelInput) function must be async.")).true();

});

await TestRunner.test("KitComponent - onRenderComplete()", async t => {

    // arrange
    let renderCompleteCalled = false;
    let options = {
        model: {
            onRenderComplete: async function () {
                renderCompleteCalled = true;
            }
        }
    };
    const component = new KitComponent(options);

    // act
    component.onRenderComplete();

    // assert
    t.is(renderCompleteCalled).true();

});

await TestRunner.test("KitComponent - onRenderComplete() must be async", async t => {

    // arrange
    let renderCompleteCalled = false;
    let options = {
        model: {
            onRenderComplete: function () {
                renderCompleteCalled = true;
            }
        }
    };
    const component = new KitComponent(options);
    let actual = null;

    // act
    try {
        component.onRenderComplete();
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual.startsWith("onRenderComplete() function must be async.")).true();

});

await TestRunner.test("KitComponent - find()", async t => {

    // arrange
    let options = {
        model: "unit-test"
    };
    const expected = new KitComponent(options);
    KitComponent.add(expected);

    // act
    const actual = KitComponent.find(expected.id);

    // assert
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitComponent - add()", async t => {

    // arrange
    let options = {
        model: "unit-test"
    };
    const expected = new KitComponent(options);

    // act
    KitComponent.add(expected);
    
    // assert
    const actual = KitComponent.find(expected.id);
    t.is(actual).equalTo(expected);

});

await TestRunner.test("KitComponent - remove()", async t => {

    // arrange
    let options = {
        model: "unit-test"
    };
    const expected = new KitComponent(options);
    KitComponent.add(expected);

    // act
    KitComponent.remove(expected.id);

    // assert
    const actual = KitComponent.find(expected.id);
    t.is(actual).falsy();

});

// KitRenderer tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitRenderer - renderDocument()", async t => {

    // arrange
    let actualComponentId = null;
    const mockDocument = {
        body: {
            innerHTML: "unit-test",
            setAttribute(qualifiedName, value) {
                if (qualifiedName === "data-kit-component-id") {
                    actualComponentId = value;
                }
            },
            querySelectorAll() {
                return [];
            }
        },
        querySelector() {
            return this.body;
        },
        createElement() {
            return {
                innerHTML: null,
                querySelectorAll() {
                    return [];
                }
            };
        }
    };
    KitDependencyManager.setDocument(mockDocument);

    // act
    await KitRenderer.renderDocument();

    // assert
    t.is(actualComponentId).truthy();

});

await TestRunner.test("KitRenderer - renderComponent() - no component", async t => {

    // arrange
    let querySelectorCalled = false;
    const mockDocument = {
        querySelector() {
            querySelectorCalled = true;
            return null;
        }
    };
    KitDependencyManager.setDocument(mockDocument);

    // act
    await KitRenderer.renderComponent(1);

    // assert
    t.is(querySelectorCalled).true();

});

await TestRunner.test("KitRenderer - renderComponent()", async t => {

    // arrange
    let childComponentId = null;
    const parentTemplate = "parent";
    const childTemplate = "child - \\#unitTestModel - #unitTestModel \\%{'testing'\\}% %{'testing'}%";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-COMPONENT";
    mockDocument.childElement.testAttributes["data-kit-model-input"] = "'unit-test-input'";
    mockDocument.childElement.testAttributes["data-kit-model-ref"] = "unitTestModel";
    const prop1 = "prop1";
    const prop2Value = "abc";
    const prop2 = `prop2=${prop2Value}`;
    mockDocument.childElement.testAttributes["data-kit-add-attributes"] = `${prop1},${prop2}`;
    KitDependencyManager.setDocument(mockDocument);

    // act
    await KitRenderer.renderComponent(parentComponent.id);

    // assert
    const prop1Actual = mockDocument.childElement.testAttributes["prop1"];
    const prop2Actual = mockDocument.childElement.testAttributes["prop2"];
    t.is(childComponentId).truthy();
    t.is(prop1Actual).equalTo("");
    t.is(prop2Actual).equalTo(prop2Value);

});

await TestRunner.test("KitRenderer - renderComponent() - template path", async t => {

    // arrange
    let childComponentId = null;
    const parentTemplate = "parent";
    const childTemplate = "child";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-COMPONENT";
    mockDocument.childElement.testAttributes["data-kit-model-input"] = "";
    mockDocument.childElement.testAttributes["data-kit-template-path"] = "unit-test-path";
    KitDependencyManager.setDocument(mockDocument);
    const mockResourceManager = arrangeResourceManager();
    KitDependencyManager.setResourceManager(mockResourceManager);

    // act
    await KitRenderer.renderComponent(parentComponent.id);

    // assert
    t.is(childComponentId).truthy();

});

await TestRunner.test("KitRenderer - renderComponent() - template path from cache", async t => {

    // arrange
    let childComponentId = null;
    const parentTemplate = "parent";
    const childTemplate = "child";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-COMPONENT";
    mockDocument.childElement.testAttributes["data-kit-template-path"] = "unit-test-path";
    KitDependencyManager.setDocument(mockDocument);
    const mockResourceManager = arrangeResourceManager();
    KitDependencyManager.setResourceManager(mockResourceManager);
    await KitRenderer.renderComponent(parentComponent.id);

    // act
    await KitRenderer.renderComponent(parentComponent.id);

    // assert
    t.is(childComponentId).truthy();

});

await TestRunner.test("KitRenderer - renderComponent() - template path - template not found at path", async t => {

    // arrange
    let childComponentId = null;
    const path = "unit-test-path-not-found";
    const parentTemplate = "parent";
    const childTemplate = "child";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-COMPONENT";
    mockDocument.childElement.testAttributes["data-kit-template-path"] = path;
    KitDependencyManager.setDocument(mockDocument);
    const fetchFunction = async function () {
        return {
            async text() {
                return null;
            }
        };
    };
    const mockResourceManager = arrangeResourceManager(fetchFunction);
    KitDependencyManager.setResourceManager(mockResourceManager);
    let actual = null;

    // act
    try {
        await KitRenderer.renderComponent(parentComponent.id);
    }
    catch (error) {
        actual = error.message;
    }
    
    // assert
    t.is(actual).equalTo(`template not found at path: ${path}`);

});

await TestRunner.test("KitRenderer - renderComponent() - template path - missing createModel() function", async t => {

    // arrange
    let childComponentId = null;
    const path = "unit-test-path";
    const parentTemplate = "parent";
    const childTemplate = "child";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-COMPONENT";
    mockDocument.childElement.testAttributes["data-kit-template-path"] = path;
    KitDependencyManager.setDocument(mockDocument);
    const importFunction = async function () {
        return {};
    };
    const mockResourceManager = arrangeResourceManager(null, importFunction);
    KitDependencyManager.setResourceManager(mockResourceManager);
    let actual = null;

    // act
    try {
        await KitRenderer.renderComponent(parentComponent.id);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(`missing required function export 'createModel()'. modulePath: ${path}`);

});

await TestRunner.test("KitRenderer - renderComponent() - template path - createModel() function does not return a model", async t => {

    // arrange
    let childComponentId = null;
    const path = "unit-test-path";
    const parentTemplate = "parent";
    const childTemplate = "child";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-COMPONENT";
    mockDocument.childElement.testAttributes["data-kit-template-path"] = path;
    KitDependencyManager.setDocument(mockDocument);
    const importFunction = async function () {
        return {
            createModel() {
                return null;
            }
        };
    };
    const mockResourceManager = arrangeResourceManager(null, importFunction);
    KitDependencyManager.setResourceManager(mockResourceManager);
    let actual = null;

    // act
    try {
        await KitRenderer.renderComponent(parentComponent.id);
    }
    catch (error) {
        actual = error.message;
    }

    // assert
    t.is(actual).equalTo(`function createModel() did not return a model object. modulePath: ${path}`);

});

await TestRunner.test("KitRenderer - renderComponent() - conditional", async t => {

    // arrange
    let childComponentId = null;
    const parentTemplate = "parent";
    const childTemplate = "child";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-IF";
    mockDocument.childElement.testAttributes["data-kit-condition"] = "true";
    KitDependencyManager.setDocument(mockDocument);

    // act
    await KitRenderer.renderComponent(parentComponent.id);

    // assert
    t.is(childComponentId).truthy();

});

await TestRunner.test("KitRenderer - renderComponent() - array", async t => {

    // arrange
    let childComponentId = null;
    const parentTemplate = "parent";
    const childTemplate = "child - #unitTestItemIndex";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-ARRAY";
    mockDocument.childElement.testAttributes["data-kit-array"] = "['a', 'b', 'c']";
    mockDocument.childElement.testAttributes["data-kit-array-ref"] = "unitTestArray";
    mockDocument.childElement.testAttributes["data-kit-item-ref"] = "unitTestItem";
    mockDocument.childElement.testAttributes["data-kit-item-index-ref"] = "unitTestItemIndex";
    KitDependencyManager.setDocument(mockDocument);

    // act
    await KitRenderer.renderComponent(parentComponent.id);

    // assert
    t.is(childComponentId).truthy();

});

await TestRunner.test("KitRenderer - renderComponent() - model initialize()", async t => {

    // arrange
    let childComponentId = null;
    const parentTemplate = "parent";
    const childTemplate = "child";
    const parentComponent = arrangeComponent(parentTemplate, null);
    const childComponent = arrangeComponent(childTemplate, parentComponent);
    const mockDocument = arrangeDocument(childComponent.id, childTemplate, value => childComponentId = value, parentComponent.id, parentTemplate);
    mockDocument.childElement.tagName = "KIT-COMPONENT";
    mockDocument.childElement.testAttributes["data-kit-model"] = "{ async initialize(){}}";
    KitDependencyManager.setDocument(mockDocument);

    // act
    await KitRenderer.renderComponent(parentComponent.id);

    // assert
    t.is(childComponentId).truthy();

});

await TestRunner.test("KitRenderer - getComponentElement()", async t => {

    // arrange
    const expected = "unit-test";
    const mockDocument = {
        querySelector() {
            return expected;
        }
    };
    KitDependencyManager.setDocument(mockDocument);

    // act
    const actual = KitRenderer.getComponentElement(1);

    // assert
    t.is(actual).equalTo(expected);

});

// KitStartup tests
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
await TestRunner.test("KitStartup - initialize()", async t => {

    // arrange
    let actualComponentId = null;
    const mockWindow = {
        addEventListener() { },
    };
    globalThis.window = mockWindow;
    const mockDocument = arrangeDocumentForStartup(value => actualComponentId = value);
    globalThis.document = mockDocument; 
    KitDependencyManager.setDocument(mockDocument);
    const component = new KitComponent({});
    KitComponent.add(component);
    
    // act
    await KitStartup.initialize();
    const foundComponent = globalThis.window.kitComponentManager.findComponent(actualComponentId);

    // assert
    t.is(foundComponent).truthy();

});

// helpers
// ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
function arrangeDocument(childComponentId, childTemplate, setChildComponentIdCallback, parentComponentId, parentTemplate) {
    const childElement = {
        querySelectorAll() {
            return [];
        },
        getAttribute(qualifiedName) {
            if (qualifiedName === "data-kit-component-id") {
                return childComponentId;
            }
            return this.testAttributes[qualifiedName];
        },
        innerHTML: childTemplate,
        tagName: null,
        setAttribute(qualifiedName, value) {
            if (qualifiedName === "data-kit-component-id") {
                setChildComponentIdCallback(value);
            }
            else {
                this.testAttributes[qualifiedName] = value;
            }
        },
        testAttributes: {},
        hasAttribute(qualifiedName) {
            if (this.testAttributes[qualifiedName] || this.testAttributes[qualifiedName] === "") {
                return true;
            }
            return false;
        },
        append() { },
        removeAttribute() { }
    };
    const parentElement = {
        querySelectorAll() {
            return new Array(childElement);
        },
        innerHTML: parentTemplate
    };
    return {
        parentElement: parentElement,
        childElement: childElement,
        querySelector(selector) {
            if (selector === `[data-kit-component-id="${parentComponentId}"]`) {
                return parentElement;
            }
            return childElement;
        },
        createElement() {
            return {
                innerHTML: null,
                querySelectorAll(selector) {
                    if (selector.includes(":is")) {
                        return [];
                    }
                    if (this.innerHTML === parentTemplate) {
                        return new Array(childElement);
                    }
                    return [];
                },
                setAttribute() { }
            };
        }
    };
}

function arrangeDocumentForStartup(setComponentIdCallback) {
    return {
        body: {
            innerHTML: "unit-test",
            setAttribute(qualifiedName, value) {
                if (qualifiedName === "data-kit-component-id") {
                    setComponentIdCallback(value);
                }
            },
            querySelectorAll() {
                return [];
            },
            addEventListener() { }
        },
        querySelector() {
            return this.body;
        },
        createElement() {
            return {
                innerHTML: null,
                querySelectorAll() {
                    return [];
                }
            };
        },
        location: {
            href: null
        }
    };
}

function arrangeComponent(template, parent) {
    const options = {
        template: template,
        parent: parent
    };
    const component = new KitComponent(options);
    KitComponent.add(component);
    return component;
}

function arrangeResourceManager(fetchFunction, importFunction) {
    if (!fetchFunction) {
        fetchFunction = async function () {
            return {
                async text() {
                    return "unit-test-template";
                }
            };
        };
    }
    if (!importFunction) {
        importFunction = async function () {
            return {
                createModel() {
                    return "unit-test-model";
                }
            };
        };
    }
    return {
        fetch: fetchFunction,
        import: importFunction
    };
}
