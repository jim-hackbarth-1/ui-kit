
import { fileURLToPath } from "node:url";
import process from "node:process";
import * as fs from "fs";
import inspector from "inspector/promises";
import { readFile } from "node:fs/promises";

export class TestRunner {

    constructor() {
        this.currentAssertion = null;
        this.currentError = null;
    }

    static testCount = 0;
    static passingTestCount = 0;
    static failingTestCount = 0;

    static clearTestCounts() {
        TestRunner.testCount = 0;
        TestRunner.passingTestCount = 0;
        TestRunner.failingTestCount = 0;
    }

    static async test(testName, testFunction) {
        if (!TestConfig.isTestPatternMatch(testName)) {
            return;
        }
        const testRunner = new TestRunner();
        try {
            await testFunction(testRunner);
        }
        catch (error) {
            testRunner.currentAssertion = new TestAssertion(false, null, "Exception thrown:");
            testRunner.currentError = error;
        }
        if (!testRunner.currentAssertion) {
            testRunner.currentAssertion = new TestAssertion(false, null, `No assertions found in test ${testName}.`);
        }
        const testReporter = new TestReporter();
        TestRunner.testCount++;
        if (testRunner.currentAssertion.value === true) {
            TestRunner.passingTestCount++;
            testReporter.reportPassResult(`Test "${testName}" passed`);
        }
        else {
            TestRunner.failingTestCount++;
            testReporter.reportFailResult(`Test "${testName}" failed`, testRunner.currentAssertion, testRunner.currentError);
        }
        TestReporter.appendResults(testReporter.testResults);
    }

    pass() {
        if (!this.currentAssertion) {
            this.currentAssertion = new TestAssertion(true, "pass()", null);
        }
    }

    fail(failureMessage) {
        if (!this.currentAssertion || this.currentAssertion.value) {
            this.currentAssertion = new TestAssertion(false, "fail()", failureMessage);
        }
    }

    is(value) {
        return new TestOperand(this, value);
    }

    isJson(value) {
        return this.is(JSON.stringify(value));
    }
}

export class TestConfig {

    constructor(applicationFolder, testFilePatterns, coverage, reportPath) {
        this.applicationFolder = applicationFolder;
        this.testFilePatterns = testFilePatterns;
        this.coverage = coverage;
        this.reportPath = reportPath;
    }

    static testNamePattern = TestConfig.#getCommandLineArgument("-test-name-pattern:");
    static currentFilePath = fileURLToPath(import.meta.url);

    static isTestPatternMatch(testName) {
        if (TestConfig.testNamePattern) {
            const regex = new RegExp(TestConfig.testNamePattern);
            return regex.test(testName);
        }
        return true;
    }

    static getConfig() {

        // default config
        let singleTestFile = false;
        let config = new TestConfig(
            "./",
            [new TestConfigFilePattern("./", ".test.js")],
            new TestConfigCoverage(true, 80, 60, []),
            "./test-report.txt");

        // config from command line argument (if any)
        const configPath = TestConfig.#getCommandLineArgument("-config-path:");
        if (configPath && fs.existsSync(configPath)) {
            config = JSON.parse(fs.readFileSync(configPath, "utf8"));
            config = new TestConfig(
                config.applicationFolder, config.testFilePatterns, config.coverage, config.reportPath);
        }

        // override config from additional command line arguments (if any)
        const applicationFolder = TestConfig.#getCommandLineArgument("-application-folder:");
        if (applicationFolder && fs.existsSync(applicationFolder)) {
            config.applicationFolder = applicationFolder;
        }

        const testFile = TestConfig.#getCommandLineArgument("-test-file:");
        if (testFile && fs.existsSync(testFile)) {
            singleTestFile = true;
            config.testFilePatterns = [new TestConfigFilePattern(testFile, testFile)];
        }

        if (singleTestFile) {
            config.coverage.gatherCoverageData = false;
        }
        else {
            const gatherCoverageData = TestConfig.#getCommandLineArgument("-gather-coverage-data:");
            if (gatherCoverageData) {
                config.coverage.gatherCoverageData = (gatherCoverageData === "true");
            }
        }

        const applicationMinCoveragePercentage = TestConfig.#getCommandLineArgument("-application-min-coverage-percentage:");
        if (applicationMinCoveragePercentage) {
            const percentValue = Number.parseFloat(applicationMinCoveragePercentage);
            if (!Number.isNaN(percentValue)) {
                config.coverage.applicationMinCoveragePercentage = percentValue;
            }
        }

        const fileMinCoveragePercentage = TestConfig.#getCommandLineArgument("-file-min-coverage-percentage:");
        if (fileMinCoveragePercentage) {
            const percentValue = Number.parseFloat(fileMinCoveragePercentage);
            if (!Number.isNaN(percentValue)) {
                config.coverage.fileMinCoveragePercentage = percentValue;
            }
        }

        const excludeFile = TestConfig.#getCommandLineArgument("-exclude-file-from-coverage:");
        if (excludeFile && fs.existsSync(excludeFile)) {
            config.coverage.excludeFilePatterns = [new TestConfigFilePattern(excludeFile, excludeFile)];
        }

        const reportPath = TestConfig.#getCommandLineArgument("-report-path:");
        if (reportPath && fs.existsSync(reportPath)) {
            config.reportPath = reportPath;
        }

        return config;
    }

    getTestFiles() {
        return this.#getFilesRecurse(this.applicationFolder, true);
    }

    getSrcFiles() {
        return this.#getFilesRecurse(this.applicationFolder, false);
    }

    static #getCommandLineArgument(argumentName) {
        let configArg = process.argv.find(a => a.startsWith(argumentName));
        if (configArg) {
            return configArg.replace(argumentName, "");
        }
        return "";
    }

    #getFilesRecurse(directoryPath, getTestFiles) {
        const files = [];
        const entries = fs.readdirSync(directoryPath, { withFileTypes: true });
        for (const entry of entries) {
            if (entry.isDirectory()) {
                const entryFiles = this.#getFilesRecurse(entry.path + entry.name + "/", getTestFiles);
                if (entryFiles && entryFiles.length > 0) {
                    files.push.apply(files, entryFiles);
                }
            }
            if (entry.isFile() && entry.name.endsWith(".js")) {
                const isTestFile = this.#isTestFile(entry.path + entry.name);
                if ((getTestFiles && isTestFile) || (!getTestFiles && !isTestFile)) {
                    files.push(entry.path + entry.name);
                }
            }
        }
        return files;
    }

    #isTestFile(filePath) {
        if (this.testFilePatterns) {
            for (const testFilePattern of this.testFilePatterns) {
                if (filePath.startsWith(testFilePattern.startsWith)
                    && filePath.endsWith(testFilePattern.endsWith)) {
                    return true;
                }
            }
        }
        return false;
    }
}

export class TestConfigFilePattern {
    constructor(startsWith, endsWith) {
        this.startsWith = startsWith;
        this.endsWith = endsWith;
    }
}

export class TestConfigCoverage {
    constructor(gatherCoverageData, applicationMinCoveragePercentage, fileMinCoveragePercentage, excludeFilePatterns) {
        this.gatherCoverageData = gatherCoverageData;
        this.applicationMinCoveragePercentage = applicationMinCoveragePercentage;
        this.fileMinCoveragePercentage = fileMinCoveragePercentage;
        this.excludeFilePatterns = excludeFilePatterns;
    }
}

export class TestOperand {

    constructor(testRunner, value) {
        this.testRunner = testRunner;
        this.value = value;
    }

    true(failureMessage) {
        if (this.#doAssertion()) {
            const assertionValue = (this.value === true);
            this.testRunner.currentAssertion
                = new TestAssertion(assertionValue, "true()", failureMessage, { value: this.value });
        }
    }

    false(failureMessage) {
        if (this.#doAssertion()) {
            const assertionValue = (this.value !== true);
            this.testRunner.currentAssertion
                = new TestAssertion(assertionValue, "false()", failureMessage, { value: this.value });
        }
    }

    truthy(failureMessage) {
        if (this.#doAssertion()) {
            let assertionValue = false;
            if (this.value) {
                assertionValue = true;
            }
            this.testRunner.currentAssertion
                = new TestAssertion(assertionValue, "truthy()", failureMessage, { value: this.value });
        }
    }

    falsy(failureMessage) {
        if (this.#doAssertion()) {
            let assertionValue = false;
            if (!this.value) {
                assertionValue = true;
            }
            this.testRunner.currentAssertion
                = new TestAssertion(assertionValue, "falsy()", failureMessage, { value: this.value });
        }
    }

    equalTo(value, failureMessage) {
        if (this.#doAssertion()) {
            const assertionValue = (this.value === value);
            this.testRunner.currentAssertion
                = new TestAssertion(assertionValue, "equalTo()", failureMessage, { value1: this.value, value2: value });
        }
    }

    equalToJson(value, failureMessage) {
        if (this.#doAssertion()) {
            const json = JSON.stringify(value);
            const assertionValue = (this.value === json);
            this.testRunner.currentAssertion
                = new TestAssertion(assertionValue, "equalToJson()", failureMessage, { value1: this.value, value2: json });
        }
    }

    #doAssertion() {
        return (!this.currentAssertion || this.currentAssertion.value);
    }
}

export class TestAssertion {
    constructor(value, assertionMethod, failureMessage, data) {
        this.value = value;
        this.assertionMethod = assertionMethod;
        this.failureMessage = failureMessage;
        this.data = data;
        this.failureStack = this.#generateFailureStack();
    }

    getFailureLocationLine() {
        if (this.failureStack) {
            let currentFileName = TestConfig.currentFilePath;
            currentFileName = currentFileName.replaceAll("\\", "/");
            const line = this.failureStack.split("\n").find(l => !l.startsWith("Error") && !l.includes(currentFileName));
            return line;
        }
        return "";
    }

    #generateFailureStack() {
        if (!this.value) {
            return new Error().stack;
        }
        return "";
    }
}

export class TestReporter {

    constructor() {
        this.testResults = [];
    }

    static testResults = [];

    static COLORS = {
        RESET: "\x1b[0m",
        RED: "\x1b[31m",
        GREEN: "\x1b[32m",
        YELLOW: "\x1b[33m",
    };

    static SPECIAL_CHARACTERS = {
        GREEN_CHECKMARK: "\x1b[32m\u2714\x1b[0m",
        YELLOW_WARNING_SIGN: "\x1b[33m\u26a0\x1b[0m",
        RED_X: "\x1b[31m\u2718\x1b[0m"
    };

    static RESULT_TYPE = {
        PASS: "pass",
        FAIL: "fail",
        WARN: "warn",
        INFO: "info"
    };

    static appendResults(testResults) {
        TestReporter.testResults.push.apply(TestReporter.testResults, testResults);
    }

    static appendResult(result, formattedResult) {
        console.log(formattedResult ?? result);
        TestReporter.testResults.push(result);
    }

    reportPassResult(result) {
        this.reportResult(result, `${TestReporter.SPECIAL_CHARACTERS.GREEN_CHECKMARK}  ${result}`);
    }

    reportFailResult(result, assertion, error) {
        const indent = "   ";
        this.reportResult(result, `${TestReporter.SPECIAL_CHARACTERS.RED_X}  ${result}`);
        if (assertion) {
            if (assertion.assertionMethod) {
                this.reportResult(`${indent}${assertion.assertionMethod} assertion failed.  ${assertion.failureMessage ?? ""}`);
                if (assertion.data) {
                    this.reportResult(`${indent}${JSON.stringify(assertion.data)}`);
                    const failureLocationLine = assertion.getFailureLocationLine();
                    if (failureLocationLine) {
                        this.reportResult(`${indent}${failureLocationLine.trim()}`);
                    }
                }
            }
            else {
                this.reportResult(`${indent}${assertion.failureMessage ?? "unknown test failure"}`);
            }
        }  
        if (error) {
            this.reportResult(`${indent}${error.stack}`);
        }
    }

    reportResult(result, formattedResult) {
        console.log(formattedResult ?? result);
        this.testResults.push(result);
    }
}

export class TestCoverageRunner {

    constructor() {
        this.testReporter = new TestReporter();
    }

    #coverageSession = null;
    #coverage = null;

    async startCoverage() {
        this.#coverageSession = new inspector.Session();
        this.#coverageSession.connect();
        await this.#coverageSession.post("Profiler.enable");
        await this.#coverageSession.post("Profiler.startPreciseCoverage", {
            callCount: true,
            detailed: true
        });
    }

    async stopCoverage() {
        this.#coverage = await this.#coverageSession.post("Profiler.takePreciseCoverage");
        await this.#coverageSession.post("Profiler.stopPreciseCoverage");
    }

    async reportCoverageResults(testFiles, testReporter, config) {
        const coverageResults = this.#filterCoverageResults(testFiles);
        let totalRangeCount = 0;
        let totalCoveredRangeCount = 0;
        testReporter.reportResult("COVERAGE", `\n${TestReporter.COLORS.YELLOW}COVERAGE${TestReporter.COLORS.RESET}`);
        testReporter.reportResult(`File minimum coverage: ${config.coverage.fileMinCoveragePercentage}%`);
        testReporter.reportResult(`Application minimum coverage: ${config.coverage.applicationMinCoveragePercentage}%`);
        for (const coverageResult of coverageResults) {
            const rangeCounts = await this.#reportCoverageResult(coverageResult, testReporter, config);
            totalRangeCount += rangeCounts.rangeCount;
            totalCoveredRangeCount += rangeCounts.coveredRangeCount;
        }
        if (totalRangeCount > 0) {
            const totalPercentCovered = (totalCoveredRangeCount / totalRangeCount) * 100;
            testReporter.reportResult("APPLICATION COVERAGE", "\nAPPLICATION COVERAGE");
            const reportResult = `${totalCoveredRangeCount} of ${totalRangeCount} ranges covered: ${totalPercentCovered.toFixed(2)}%`;
            if (totalPercentCovered >= config.coverage.applicationMinCoveragePercentage) {
                testReporter.reportResult(reportResult, `${TestReporter.SPECIAL_CHARACTERS.GREEN_CHECKMARK} ${totalCoveredRangeCount} of ${totalRangeCount} ranges covered: ${TestReporter.COLORS.GREEN}${totalPercentCovered.toFixed(2)}%${TestReporter.COLORS.RESET}`);
            }
            else {
                testReporter.reportResult(reportResult, `${TestReporter.SPECIAL_CHARACTERS.RED_X} ${totalCoveredRangeCount} of ${totalRangeCount} ranges covered: ${TestReporter.COLORS.RED}${totalPercentCovered.toFixed(2)}%${TestReporter.COLORS.RESET}`);
            }
        }
    }

    isFileExcludedFromCoverage(filePath, config) {
        if (config.coverage.excludeFilePatterns) {
            for (const excludeFilePattern of config.coverage.excludeFilePatterns) {
                if (filePath.startsWith(excludeFilePattern.startsWith) && filePath.endsWith(excludeFilePattern.endsWith)) {
                    return true;
                }
            }
        }
        return false;
    }

    #filterCoverageResults(testFiles) {
        const currentFile = TestConfig.currentFilePath.replaceAll("\\", "/");
        return this.#coverage.result.filter(cr => {
            if (!cr.url.startsWith("file:///")) {
                return false;
            }
            if (cr.url.includes(currentFile)) {
                return false;
            }
            for (const testFile of testFiles) {
                if (cr.url.includes(testFile.substring(1))) {
                    return false;
                }
            }
            return true;
        });
    }

    async #reportCoverageResult(coverageResult, testReporter, config) {
        const filePath = fileURLToPath(coverageResult.url);
        const excludeFromCoverage = this.isFileExcludedFromCoverage(filePath, config);
        if (excludeFromCoverage) {
            return {
                rangeCount: 0,
                coveredRangeCount: 0
            };
        }
        const sourceCode = await readFile(filePath, "utf8");
        testReporter.reportResult(`File: ${filePath}`, `\nFile: ${filePath}`);
        let rangeCount = 0;
        let uncoveredRangeCount = 0;
        const srcLines = [];
        for (const func of coverageResult.functions) {
            rangeCount += func.ranges.length;
            if (func.functionName) {
                if (func.isBlockCoverage) {
                    for (const range of func.ranges) {
                        if (range.count === 0) {
                            uncoveredRangeCount++;
                            srcLines.push(`\nrange not covered in function ${func.functionName}:`);
                            const rangeSrc = sourceCode.substring(range.startOffset + 1, range.endOffset + 1);
                            srcLines.push(`"${rangeSrc}"`);
                        }
                    }
                }
                else {
                    uncoveredRangeCount += func.ranges.length;
                    srcLines.push(`\nfunction ${func.functionName} not covered:`);
                    const startOffset = func.ranges[0].startOffset;
                    const endOffset = func.ranges[func.ranges.length - 1].endOffset;
                    const rangeSrc = sourceCode.substring(startOffset + 1, endOffset + 1);
                    srcLines.push(`"${rangeSrc}"`);
                }
            }
        }
        let coveredRangeCount = 0;
        if (rangeCount === 0) {
            testReporter.reportFailResult("No ranges found");
        }
        else {
            coveredRangeCount = rangeCount - uncoveredRangeCount;
            const percentCovered = (coveredRangeCount / rangeCount) * 100;
            const reportResult = `${coveredRangeCount} of ${rangeCount} ranges covered: ${percentCovered.toFixed(2)}%`;
            if (percentCovered >= config.coverage.fileMinCoveragePercentage) {
                if (percentCovered >= config.coverage.applicationMinCoveragePercentage) {
                    testReporter.reportResult(reportResult, `${TestReporter.SPECIAL_CHARACTERS.GREEN_CHECKMARK}  ${coveredRangeCount} of ${rangeCount} ranges covered: ${TestReporter.COLORS.GREEN}${percentCovered.toFixed(2)}%${TestReporter.COLORS.RESET}`);
                }
                else {
                    testReporter.reportResult(reportResult, `${TestReporter.SPECIAL_CHARACTERS.YELLOW_WARNING_SIGN}  ${coveredRangeCount} of ${rangeCount} ranges covered: ${TestReporter.COLORS.YELLOW}${percentCovered.toFixed(2)}%${TestReporter.COLORS.RESET}`);
                }
            }
            else {
                testReporter.reportResult(reportResult, `${TestReporter.SPECIAL_CHARACTERS.RED_X}  ${coveredRangeCount} of ${rangeCount} ranges covered: ${TestReporter.COLORS.RED}${percentCovered.toFixed(2)}%${TestReporter.COLORS.RESET}`);
                for (const srcLine of srcLines) {
                    testReporter.reportResult(srcLine.replace("\n", ""), srcLine);
                }
            }
        }
        return {
            rangeCount: rangeCount,
            coveredRangeCount: coveredRangeCount
        };
    }
}

class CommandLine {

    static async execute(args) {
        const isCommandLineExecution = args.includes(TestConfig.currentFilePath);
        if (!isCommandLineExecution) {
            return;
        }
        TestReporter.testResults = [];
        TestRunner.clearTestCounts();
        const config = TestConfig.getConfig();
        const testFiles = config.getTestFiles();
        if (testFiles && testFiles.length > 0) {
            let testCoverageRunner = null;
            if (config.coverage.gatherCoverageData) {
                testCoverageRunner = new TestCoverageRunner();
                await testCoverageRunner.startCoverage();

                // let coverage runner know of existence of all src files 
                // in case they are not covered at all
                const srcFiles = config.getSrcFiles();
                for (const srcFile of srcFiles) {
                    const isExcluded = testCoverageRunner.isFileExcludedFromCoverage(srcFile, config);
                    if (!isExcluded) {
                        await import(srcFile);
                    }
                }
            }
            TestReporter.appendResult("TESTS", `\n${TestReporter.COLORS.YELLOW}TESTS${TestReporter.COLORS.RESET}`);
            for (const testFile of testFiles) {
                TestReporter.appendResult(`File:  ${testFile}`, `\n${TestReporter.COLORS.YELLOW}File:${TestReporter.COLORS.RESET}  ${testFile}`);
                await import(testFile);
            }
            TestReporter.appendResult(`TOTAL TESTS: ${TestRunner.testCount}`, `\nTOTAL TESTS: ${TestRunner.testCount}`);
            TestReporter.appendResult(`Passing tests: ${TestRunner.passingTestCount}`, `${TestReporter.SPECIAL_CHARACTERS.GREEN_CHECKMARK}  Passing tests: ${TestRunner.passingTestCount}`);
            if (TestRunner.failingTestCount > 0) {
                TestReporter.appendResult(`Failing tests: ${TestRunner.failingTestCount}`, `${TestReporter.SPECIAL_CHARACTERS.RED_X}  Failing tests: ${TestRunner.failingTestCount}`);
            }
            if (testCoverageRunner) {
                await testCoverageRunner.stopCoverage();  
                var testReporter = new TestReporter();
                await testCoverageRunner.reportCoverageResults(testFiles, testReporter, config);
                TestReporter.appendResults(testReporter.testResults);
            }
        }
        else {
            TestReporter.appendResult("No test files found", `\n${TestReporter.COLORS.RED}No test files found${TestReporter.COLORS.RESET}`);
        }
        if (config.reportPath) {
            const fileResult = {
                reportTimeUtc: new Date().toUTCString(),
                testResults: TestReporter.testResults
            };
            fs.writeFileSync(config.reportPath, JSON.stringify(fileResult, null, 4));
        }
    }
}

CommandLine.execute(process.argv);
